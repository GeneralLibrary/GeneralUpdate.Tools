﻿namespace GeneralUpdate.Core.Domain.Enum
{
    public class Format
    {
        public const string ZIP = "zip";
        public const string SEVENZIP = "7z";
    }
}