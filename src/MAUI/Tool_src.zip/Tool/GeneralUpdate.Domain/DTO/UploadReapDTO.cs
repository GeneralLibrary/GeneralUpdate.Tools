﻿using GeneralUpdate.Core.Domain.DTO;

namespace GeneralUpdate.AspNetCore.DTO
{
    public class UploadReapDTO : BaseResponseDTO<string>
    {
    }
}