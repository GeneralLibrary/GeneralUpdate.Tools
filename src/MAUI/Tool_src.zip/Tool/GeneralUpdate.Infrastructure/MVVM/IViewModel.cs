﻿namespace GeneralUpdate.Infrastructure.MVVM
{
    public interface IViewModel
    {
        void Enter();

        void Exit();
    }
}