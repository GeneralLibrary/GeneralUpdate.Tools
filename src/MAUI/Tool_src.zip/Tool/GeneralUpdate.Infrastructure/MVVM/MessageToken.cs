﻿namespace GeneralUpdate.Infrastructure.MVVM
{
    public class MessageToken
    {
        public const string FilesMessageToken = "FilesMessageToken";
    }
}